function [red] = proof(phi_filt, dphi_filt, parameter, filename)
% Die Funktion berechnet aus den �bergebenen gefilterten
% Messdaten die G�te Ihrer D�mpfungsfunktion.

% Input:    phi_filt:     Der gefilterte Pendelwinkel
%           dphi_filt:    Die gefilterte Winkelgeschwindigkeit
%           parameter:    Die Parameterstruktur

% Output:   red:          Die Reduzierung des Modellfehlers gegen�ber dem
%                         unged�mpften Modell.


tspan = [0 (length(phi_filt)-1)*0.01]; %Zeitbereich f�r die numerische Integration
x0 = [phi_filt(1) dphi_filt(1)];    %Startwerte der numerischen Integration

%Numerische Integration des Modells mit D�mpfungsfunktion
[t1,x1] = ode45(@(t,x) pendel(t,x,parameter), tspan, x0);

%Anpassung der Parameterstruktur
parameter2 = parameter;
parameter2.func='0';
%Numerische Integration des Modells ohne D�mpfungsfunktion
[t2,x2] = ode45(@(t,x) pendel(t,x,parameter2), tspan, x0);

t0 = 0:0.01:(length(phi_filt)-1)*0.01; %Auswertezeitpunkte der L�sung

%Bestimmung der Winkel an den Auswertezeitpunkten mit und ohne D�mpfung
x1 = interp1(t1,x1(:,1),t0,'spline'); 
x2 = interp1(t2,x2(:,1),t0,'spline');


%Bestimmung des quadratischen Fehlers und Ermittlung der Reduzierung des
%Modellfehlers
diff = mean(phi_filt)-pi; %Aufgrund schlechter Kalibrierung ist der mittlere Winkel nicht pi.
rms_d = 0;
rms =0;
for i = 1:length(x1)
    rms_d = rms_d + (phi_filt(i)-diff-x1(i))^2; %Fehler mit D�mpfung
    rms = rms + (phi_filt(i)-diff-x2(i))^2;  %Fehler ohne D�mpfung
end
rms_d = sqrt(rms_d/length(x1));
rms = sqrt(rms/length(x1));
red = (1-rms_d/rms);
if red <0
    red=0;
end

figure
plot(t0,phi_filt-diff,'k',t0,x1,'r',t0,x2,'b');
legend('Messung','Ged�mpft','Unged�mpft');
xlabel('t [s]')
ylabel('\phi [rad]')
title(strcat({'�bereinstimmung f�r die Datei '}, filename))
