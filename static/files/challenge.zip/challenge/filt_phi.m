function [t,phi,phi_filt,dphi_filt,ddphi_filt] = filt_phi(filename)
% Die Funktion liest die Werte der csv-Tabelle mit dem Namen filename aus
% (diese muss sich in demselben Verzeichnis wie die Funktion befinden). Die
% gemessenen Winkel werden gefiltert und die Ableitungen durch Bildung des
% Differenzenquotienten gebildet.

% Input:    filename:   Der Dateiname der Tabelle im Format 'beispiel.csv'

% Output:   t:          Zeit [s]
%           phi:        der gemessenen Winkel [rad]
%           phi_filt:   der tiefpassgefilterte Winkel [rad]
%           dphi:       die Geschwindigkeit von phi_filt [rad/s]
%           ddphi:      die Beschleunigung von phi_filt [rad/s�]
a = dlmread(filename,';',1,0);  %�ffnen und lesen der Datei
t = a(:,1);
phi(:,1) = a(:,2);
% Die Datei filename wird ausgelesen und jede Zeile als Vektor mit 2
% Dezimalwerten interpretiert (%f %f = float float bzw. double double). Das
% Trennzeichen zwischen den Splaten wird mit ; angegeben.

f = 1/mean(diff(t));    %die Abtastfrequenz ergibt sich aus der mittleren 
                        % Abtastzeit 

[b,a] = butter(4,2/(f/2));    % Tiefpass-Filter 4. Ordnung, mit einer 
                              % Abtastrate von f (kleinste beobacht-
                              % bare Frequenz nach Nyquist= f/2),
                              % Grenzfrequenz = 5Hz (Abfallen der
                              % Amplitude auf 1/e)
phi_filt = filtfilt(b,a,phi); % Filtern der Messwerte

%da das Filter keine Startwerte hat und sowohl vorw�rts als auch r�ckw�rts 
%l�uft, werden die ersten und letzten 100 Werte nicht ber�cksichtigt.
phi_filt=phi_filt(100:end-100);

dphi  = diff(phi_filt)*f;	% Bildung des Differenzenquotienten zur
                            % Bestimmung der Winkelgeschwindigkeit
ddphi_filt = diff(dphi)*f;

%da das Filter keine Startwerte hat und sowohl vorw�rts als auch r�ckw�rts 
%l�uft, werden die ersten und letzten 100 Werte nicht ber�cksichtigt.


% Da die Ableitungen durch Differenzbildung berechnet werden, ist der
% Zeitpunkt der Ableitung gegen�ber dem urspr�nglichen Signal um die halbe
% Abtastzeit verschoben. Daher werden nachfolgend die Geschwindigkeit und
% Position auf die Beschleunigung angepasst.
for i = 1:size(dphi,1)-1
    dphi_filt(i,1) = (dphi(i+1)+dphi(i))/2; 
    % Verschiebung der Geschwindigkeiten.
end

%Reduzierung/Verschiebung der Messwerte auf das Beschleunigungssignal
t = t(2:end-1,1);
phi = phi(2:end-1,1);
phi_filt = phi_filt(2:end-1,1);