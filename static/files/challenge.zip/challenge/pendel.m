function dxdt = pendel(t,x,parameter)
%Differentialgleichung des Pendels
dxdt = zeros(2,1);
m_p=parameter.m_p;
J_p=parameter.J_p;
l=parameter.l;
g=parameter.g;
func=parameter.func;
eq = inline(func,'phi','dphi'); %Auswertung der Pendelfunktion
dxdt(1) = x(2);
dxdt(2) = (-0.5*l*m_p*g*(x(1)-pi)-eq(x(1),x(2)))/(J_p+0.25*m_p*l^2);