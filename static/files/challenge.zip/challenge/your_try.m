%pkg load signal   %Kommentieren Sie diese Zeile bitte ein, falls Sie Octave benutzen.
close all;
l = 0; %Die identifizierte L�nge des Pendels in m
m_p = 0; %Die identifizierte Masse des Pendels in kg
J_p= 0; %Das Massentr�gheitsmoment des Pendels bzgl. seines Schwerpunktes
func = 'asin(phi*dphi-200)';   %Ihre D�mpfungsfunktion
filenames = {'schwach.csv', 'mittel.csv', 'stark.csv'}; %Die Dateien bzgl. derer Ihr Modell bewertet werden soll. Diese
                                                           %m�ssen sich im selben Verzeichnis wie die Skripdateien befinden.                                   

g=9.81; %Erdbeschleunigung in m/s�
parameter = struct('l',l,'m_p',m_p,'J_p',J_p,'func',func,'g',g);

% Die Messdaten aus den drei Dateien werden tiefpassgefitlert
[t1,phi1,phi_filt1,dphi_filt1,ddphi_filt1] = filt_phi(filenames{1});
[t2,phi2,phi_filt2,dphi_filt2,ddphi_filt2] = filt_phi(filenames{2});
[t3,phi3,phi_filt3,dphi_filt3,ddphi_filt3] = filt_phi(filenames{3});

% Es wird die Verbesserung gegen�ber einem unged�mpften System ermittelt
red1 = proof(phi_filt1, dphi_filt1, parameter, filenames(1));
red2 = proof(phi_filt2, dphi_filt2, parameter, filenames(2));
red3 = proof(phi_filt3, dphi_filt3, parameter, filenames(3));

red = (red1*red2*red3)^(1/3);
disp(strcat('Die gemittelte Verbesserung �ber alle Daten betr�gt: ', num2str(red*100),' %'))