Camera Calibration Toolbox for Matlab
-------------------------------------

The complete documentation of this toolbox is available online at
http://www.vision.caltech.edu/bouguetj/calib_doc/

The lastest version of the toolbox can also be downloaded from this web site.

If you have any question/suggestion/bug report please send me email at
jean-yves.bouguet@intel.com


Enjoy the toolbox!


Jean-Yves Bouguet
Intel Corporation


October 15th, 2004