function [OriginalPic, UndistPic]=undistort_image_function(ima_name,fc, cc, alpha_c, kc, nx,ny)
%% Auszug aus der Originaldatei undistort_image.m aus der 

    %%% INPUT THE IMAGE FILE NAME:
    [filepath,name,ext] = fileparts(ima_name);
    image_name = name;
    format_image2 =ext;
    format_image2 = strrep(format_image2,'.','')
    
    
    if ~exist('fc')|~exist('cc')|~exist('kc')|~exist('alpha_c'),
        fprintf(1,'No intrinsic camera parameters available.\n');
        return;
    end;

    KK = [fc(1) alpha_c*fc(1) cc(1);0 fc(2) cc(2) ; 0 0 1];

    %%% Compute the new KK matrix to fit as much data in the image (in order to
    %%% accomodate large distortions:
    r2_extreme = (nx^2/(4*fc(1)^2) + ny^2/(4*fc(2)^2));
    dist_amount = 1; %(1+kc(1)*r2_extreme + kc(2)*r2_extreme^2);
    fc_new = dist_amount * fc;

    KK_new = [fc_new(1) alpha_c*fc_new(1) cc(1);0 fc_new(2) cc(2) ; 0 0 1];

    disp('Program that undistorts images');
    disp('The intrinsic camera parameters are assumed to be known (previously computed)');

    fprintf(1,'\n');



    %%% READ IN IMAGE:
    
    if format_image2(1) == 'p',
        if format_image2(2) == 'p',
            I = double(loadppm(ima_name));
        else
            I = double(loadpgm(ima_name));
        end;
    else
        if format_image2(1) == 'r',
            I = readras(ima_name);
        else
            I = double(imread(ima_name));
        end;
    end;
    
    % Bild ggf. resizen auf die gr��e, mit der es kalibriert wurde
    I = imresize(I,[ny nx]);
   
% %     if size(I,3)>1,
% %         I = I(:,:,2);
% %     end;
% %     
% %     
% %     if (size(I,1)>ny)|(size(I,2)>nx),
% %         I = I(1:ny,1:nx);
% %     end;
% %     

    
    if (size(I,1)>ny)|(size(I,2)>nx),
        I = I(1:ny,1:nx,:);
    end;
        
    %% SHOW THE ORIGINAL IMAGE:
    
% % %     figure(2);
% % %     image(I);
% % %     colormap(gray(256));
% % %     title('Original image (with distortion) - Stored in array I');
% % %     drawnow;
    
    
    %% UNDISTORT THE IMAGE:
    
    fprintf(1,'Computing the undistorted image...')
%       Original Code_:    
%     [I2] = rect(I,eye(3),fc,cc,kc,alpha_c,KK_new);
%       �nderung: jeden Layer seperat betrachten:
    I2=I;
    
    for i=1:size(I,3)
        I2(:,:,1) =  rect(I(:,:,1),eye(3),fc,cc,kc,alpha_c,KK_new);
    end;


    
    fprintf(1,'done\n');
    
% %     figure(3);
% %     image(I2);
% %     colormap(gray(256));
% %     title('Undistorted image - Stored in array I2');
% %     drawnow;
    
    
    %% SAVE THE IMAGE IN FILE:
    
    ima_name2 = [image_name '_rect.' format_image2];
    
    fprintf(1,['Saving undistorted image under ' ima_name2 '...']);
    
    if format_image2(1) == 'p',
        if format_image2(2) == 'p',
            saveppm(ima_name2,uint8(round(I2)));
        else
            savepgm(ima_name2,uint8(round(I2)));
        end;
    else
        if format_image2(1) == 'r',
            writeras(ima_name2,round(I2));
        else
            imwrite(uint8(round(I2)),ima_name2,format_image2);
        end;
    end;
 
% % %     ima_name3 = [image_name '_rect_gray.' format_image2];
% % %         fprintf(1,['Saving undistorted image under ' ima_name2 '...']);
% % %     
% % %     if format_image2(1) == 'p',
% % %         if format_image2(2) == 'p',
% % %             saveppm(ima_name2,uint8(round(I2)));
% % %         else
% % %             savepgm(ima_name2,uint8(round(I2)));
% % %         end;
% % %     else
% % %         if format_image2(1) == 'r',
% % %             writeras(ima_name2,round(I2),gray(256));
% % %         else
% % %             imwrite(imshow(rgb2gray(I2)),ima_name3,format_image2);
% % %         end;
% % %     end;
% % %     
    fprintf(1,'done\n');
    
    OriginalPic = uint8(round(I));
    UndistPic = uint8(round(I2));