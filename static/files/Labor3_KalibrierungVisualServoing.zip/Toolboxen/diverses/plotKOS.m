% Plotte Koordinatensystem
function[h] = plotKOS(T,mm,spec)

%spec
if ~exist('spec','var') || isempty(spec)
  spec.ColorX=[1 0 0];
  spec.ColorY=[0 1 0];
  spec.ColorZ=[0 0 1];
  spec.AxelLineStyle='-';
  spec.ColorCFO=[0 0 0];
  spec.MarkerCFO='o';
  spec.MarkerSizeCFO=5;
end

if ~exist('mm','var') || isempty(mm)
    mm=0;
end

h = gcf;

%Umrechnung von m in mm => in der GUI wird alles in m berechnet, aber
%angezeigt in mm
%skalierung
if mm==1
    T(1:3,4)=T(1:3,4)*1000; %nur translatorischen Teil umrechnen!
    % s=Modell.ModuleDiameter*1000/5;
    s=0.01*1000;
else
    s=0.005*1000;    
end

%Einheitsvektoren anlegen Zeilenweise
x = [s*1 0 0 1]';
y = [0 s*1 0 1]';
z = [0 0 s*1 1]';
temp = [0 0 0 1]';

X_E = [x y z temp];

%Koordinatentrafo der Einheitsvektoren
X_T = zeros(4,4);
for i=1:3
   X_T(:,i) = T*X_E(:,i);
end

%Koordinaten vorbereiten
for i=1:3
    x(i,1:10) = linspace(T(i,4),X_T(i,1),10);
    y(i,1:10) = linspace(T(i,4),X_T(i,2),10);
    z(i,1:10) = linspace(T(i,4),X_T(i,3),10); 
end

hold on
%Koordinatenachsen zeichnen
% plot3(x(1,:),x(2,:),x(3,:),'color','r','LineWidth',2,'erasemode','background');
% plot3(y(1,:),y(2,:),y(3,:),'color','g','LineWidth',2,'erasemode','background');
% plot3(z(1,:),z(2,:),z(3,:),'color','b','LineWidth',2,'erasemode','background');
% plot3(x(1,1), x(2,1), x(3,1),'MarkerSize',10,'Marker','o','LineWidth',2,'LineStyle','none',...
%     'Color',[1 1 0],'MarkerFaceColor',[1 1 0]);
plot3(x(1,:),x(2,:),x(3,:),'color',spec.ColorX,'LineWidth',2,'LineStyle',spec.AxelLineStyle);
plot3(y(1,:),y(2,:),y(3,:),'color',spec.ColorY,'LineWidth',2,'LineStyle',spec.AxelLineStyle);
plot3(z(1,:),z(2,:),z(3,:),'color',spec.ColorZ,'LineWidth',2,'LineStyle',spec.AxelLineStyle);
plot3(x(1,1), x(2,1), x(3,1),'MarkerSize',spec.MarkerSizeCFO,'Marker',spec.MarkerCFO,'LineWidth',2,'LineStyle','none',...
    'Color',spec.ColorCFO,'MarkerFaceColor',spec.ColorCFO);

% axis equal
hold off

end

function[X] = vec2screw(x)
    X=[0 -x(3) x(2) ; x(3) 0 -x(1) ; -x(2) x(1) 0 ];
end