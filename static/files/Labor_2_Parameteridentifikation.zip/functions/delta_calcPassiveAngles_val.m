function [phi,psi] = delta_calcPassiveAngles_val(theta,EE,kin_params)
    %Berechnet die Winkel der passiven Gelenke (NICHT EDITIEREN)
    %Eingang:
        %theta = [theta(1) theta(2) theta(3)] : Motorwinkel
        %EE = [xe ye ze]: Endeffektorposition
        %kin_params = [e f re rf] : Parameter der Kinematik
            %e: Radius der Koppelpunkte an Endeffektorplattform (80mm)
            %f: Radius bis Motorbefestigung 
            %re: L�nge Unterarm
            %rf: L�nge Oberarm 
            %Ausgang:
        %phi = [phi(1) phi(2) phi(3)] :  Winkel zwischen Ober- und Unterarm
        %psi = [psi(1) psi(2) psi(3)] : Winkel innerhalb des Parallelogramms der Teilketten
    
    
    %angle: Winkel zur Rotation des Koordinatensystems (0, 2pi/3 oder
    %-2pi/3)    
    angle=[0 2*pi/3 4*pi/3];
    e = kin_params(1);
	f = kin_params(2);
	re = kin_params(3);
	rf = kin_params(4);
     xe=EE(1);
     ye=EE(2);
     ze=EE(3);
     phi=zeros(3,1);
     psi=zeros(3,1);
    for i=1:3
        u=[
        xe + cos(angle(i))*(e - f - rf*cos(theta(i)));
        ye + sin(angle(i))*(e - f - rf*cos(theta(i)));
        ze - rf*sin(theta(i))
        ];

        %Berechnung des Vektors v, ausgehend von Koppelpunkt zwischen Ober- und
        %Unterarm in Richtung des Parallelograms
        v=[-sin(angle(i));cos(angle(i));0];

        %Berechnung des Vektors w, ausgehend von Motorwelle in Richtung des 
        %Oberarms (von Motor weg zeigend)
        w=[
            cos(angle(i))*rf*cos(theta(i));
            sin(angle(i))*rf*cos(theta(i));
            rf*sin(theta(i))
        ];

        phi(i) = -atan2(norm(cross(w,u)),dot(w,u));
        psi(i) = pi/2-atan2(norm(cross(u,v)),dot(u,v));
    end
end