function [Messdaten] = MappingData(tau_m, tau_sk, q, dtq, t)
%% MappingDaten (NICHT EDITIEREN)
% Umschreiben und und berechnen zus�tlicher Daten
%
% Eingang: 
% tau_m  - Gemessenes Drehmoment in Nm [n x 3]
% tau_sk - Berechnetes Drehmoment aus Starrk�rpermodell in Nm [n x 3]
% q      - Achswinkel in rad [n x 3]
% dtq    - Achswinkelgeschwinkel in rad/s [n x 3]
% t      - Zeitvektor in s   [n x 1]
%
% Ausgang:
% Messdaten.T1     - Zeitvektor in s   [n x 1]
% Messdaten.q      - Achswinkel in rad [n x 3]
% Messdaten.dq     - Achswinkelgeschwinkel in rad/s [n x 3]
% Messdaten.EE     - Endeffektorposition in m [n x 3]
% Messdaten.dEE    - Endeffektorgeschwindigkeit in m/s [n x 3]
% Messdaten.ddEE   - Endeffektorbeschleunigung in m/s^2 [n x 3]
% Messdaten.phi    - Passiver Gelenkwinkel in rad  [n x 3]
% Messdaten.psi    - Passiver Scherwinkel in rad  [n x 3]
% Messdaten.tau_m  - Gemessenes Drehmoment in Nm [n x 3]
% Messdaten.tau_sk - Berechnetes Drehmoment aus Starrk�rpermodell in Nm [n x 3]
%%
jdx=1; % Laufvariable
kin_params = [40,112,435,150]/1000; % Kinematikparameter des Roboters
Taktzeit = 0.001; %Taktzeit 
% Umschreiben der Daten
SizeData = size(tau_m);
for idx=1:SizeData(1,1)
    for i=1:3
        aTorque(jdx,i) = tau_m(idx,i);         %% [Nm]
        aTorque_sk(jdx,i) = tau_sk(idx,i);         %% [Nm]
        adq(jdx,i) = dtq(idx,i);%              %% [rad/s]
        aq(jdx,i) = q(idx,i);                  %% [rad]
        T1(jdx,1) = t(idx,1);
    end
    jdx=jdx+1;
end
%% Berechnung der passiven Gelenkwinkel Phi und Psi
SizeData = size(aq(:,1));
for idx=1:SizeData(1,1)
    EE(idx,:) = -delta_calcForward_val(aq(idx,:),kin_params); % [m]
    [phi(idx,:),psi(idx,:)] = delta_calcPassiveAngles_val(aq(idx,:)',EE(idx,:),kin_params); %[rad]
end
%% Berechnung der Endeffektor Geschwindigkeit und -beschleunigung durch Ableiten
dEE(:,1)  = diff(EE(:,1))/Taktzeit;
dEE(:,2)  = diff(EE(:,2))/Taktzeit;
dEE(:,3)  = diff(EE(:,3))/Taktzeit;
ddEE(:,1) = diff(dEE(:,1))/Taktzeit; 
ddEE(:,2) = diff(dEE(:,2))/Taktzeit;
ddEE(:,3) = diff(dEE(:,3))/Taktzeit;

%% Ausgabesaten
Messdaten = struct('tau_m',aTorque,'tau_sk',aTorque_sk,'dq',adq,'q',aq,'EE',EE,'dEE',dEE,'ddEE',ddEE,'phi',phi,'psi',psi,'T1',T1);
