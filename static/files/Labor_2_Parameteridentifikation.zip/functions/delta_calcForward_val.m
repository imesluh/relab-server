function [EE] = delta_calcForward_val(theta,kin_params)
    %Direkte Kinematik des 3DOF-Delta Roboters (NICHT EDITIEREN)
    %L�sung nach:
    %       The Delta Parallel Robot: Kinematics Solutions
    %       Robert L. Williams II, Ph.D.,
    %       Mechanical Engineering, Ohio University, October 2016
    %und
    %       http://forums.trossenrobotics.com/tutorials/introduction-129/delta-robot-kinematics-3276/
    
    %Eingang:
    %   theta = [theta(1) theta(2) theta(3)] : Motorwinkel
    %   kin_params = [e f re rf] : Parameter der Kinematik
    %       e: Radius der Koppelpunkte an Endeffektorplattform (80mm)
    %       f: Radius bis Motorbefestigung
    %       re: L�nge Unterarm 
    %       rf: L�nge Oberarm
    %Ausgang:
    %   EE: Endeffektorposition [xe,ye,ze]
     
    EE=zeros(1,3);
     e = kin_params(1);
	 f = kin_params(2);
	 re = kin_params(3);
	 rf = kin_params(4);
     sin30=sin(30*pi/180);
     tan60=tan(60*pi/180);
     t = (f-e);
     
     theta(1)=-theta(1);
     theta(2)=-theta(2);
     theta(3)=-theta(3);
 
     y1 = -(t + rf*cos(theta(1)));
     z1 = -rf*sin(theta(1));
 
     y2 = (t + rf*cos(theta(2)))*sin30;
     x2 = y2*tan60;
     z2 = -rf*sin(theta(2));
 
     y3 = (t + rf*cos(theta(3)))*sin30;
     x3 = -y3*tan60;
     z3 = -rf*sin(theta(3));
 
     dnm = (y2-y1)*x3-(y3-y1)*x2;
 
     w1 = y1^2 + z1^2;
     w2 = x2^2 + y2^2 + z2^2;
     w3 = x3^2 + y3^2 + z3^2;
     
     % x = (a1*z + b1)/dnm
      a1 = (z2-z1)*(y3-y1)-(z3-z1)*(y2-y1);
      b1 = -((w2-w1)*(y3-y1)-(w3-w1)*(y2-y1))/2.0;
 
     % y = (a2*z + b2)/dnm;
      a2 = -(z2-z1)*x3+(z3-z1)*x2;
      b2 = ((w2-w1)*x3 - (w3-w1)*x2)/2;
 
     % a*z^2 + b*z + c = 0
      a = a1*a1 + a2*a2 + dnm*dnm;
      b = 2*(a1*b1 + a2*(b2-y1*dnm) - z1*dnm*dnm);
      c = (b2-y1*dnm)*(b2-y1*dnm) + b1*b1 + dnm*dnm*(z1*z1 - re*re);
  
     % Diskriminante
      d = b^2 - 4*a*c;
     if (d < 0)
         xe_kin=NaN;
         ye_kin=NaN;
         ze_kin=NaN;
     end
     
     %Transformation in Koordinatensystem, das am Delta verwendet wird
     ze_kin = 0.5*(b+sqrt(d))/a;
     xe_kin = (a1*ze_kin + b1)/dnm;
     ye_kin = (a2*ze_kin + b2)/dnm;
     
    EE(1)=-ye_kin;
    EE(2)=xe_kin;
    EE(3)=ze_kin;
end